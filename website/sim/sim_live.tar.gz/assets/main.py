import asyncio
import pygame
import sys
import os
import math
import random
import time

# old sim params dict - keeping just in case
# defP = {
#     "n_days": 365, "timestep": 5, "sensor_int": 60,
#     "catchment": 12000.0, "sewage": 6.0, "pipe_cap": 350.0,
#     "max_lvl": 100.0, "runoff": 0.75,
# }

# live control variables
blk = 0        # blockage %
pop = 1.0      # pop multiplier
rn = 0         # forced rain mm
s_idx = 0      # 0=auto, 1=winter, 2=pre_monsoon, 3=monsoon, 4=post_monsoon
seasons = ["auto", "winter", "pre_monsoon", "monsoon", "post_monsoon"]
hr_add = 0     # hour scrub offset
sp = 5         # speed fps
psd = False    # pause toggle

blk_step = 10
pop_step = 0.2
rn_step = 5
sp_step = 2

# === REAL PHYSICAL AND METEOROLOGICAL CONSTANTS (from Factors.py) ===
MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"]

MONTH_TO_SEASON = {
    "January": "winter", "February": "winter",
    "March": "pre_monsoon", "April": "pre_monsoon", "May": "pre_monsoon",
    "June": "monsoon", "July": "monsoon", "August": "monsoon", "September": "monsoon",
    "October": "post_monsoon", "November": "post_monsoon", "December": "post_monsoon",
}

MONTHLY_CLIMATE = {
    "January":   {"temp_mean": 18.0, "temp_range": 4.0, "rh_mean": 58, "rh_range": 10},
    "February":  {"temp_mean": 21.0, "temp_range": 4.0, "rh_mean": 52, "rh_range": 10},
    "March":     {"temp_mean": 26.0, "temp_range": 4.5, "rh_mean": 46, "rh_range": 10},
    "April":     {"temp_mean": 30.5, "temp_range": 4.5, "rh_mean": 40, "rh_range": 10},
    "May":       {"temp_mean": 33.0, "temp_range": 4.0, "rh_mean": 44, "rh_range": 12},
    "June":      {"temp_mean": 31.0, "temp_range": 3.5, "rh_mean": 70, "rh_range": 12},
    "July":      {"temp_mean": 28.5, "temp_range": 2.5, "rh_mean": 82, "rh_range": 8},
    "August":    {"temp_mean": 28.0, "temp_range": 2.5, "rh_mean": 84, "rh_range": 8},
    "September": {"temp_mean": 28.0, "temp_range": 2.5, "rh_mean": 80, "rh_range": 8},
    "October":   {"temp_mean": 26.5, "temp_range": 3.5, "rh_mean": 66, "rh_range": 10},
    "November":  {"temp_mean": 22.5, "temp_range": 3.5, "rh_mean": 60, "rh_range": 10},
    "December":  {"temp_mean": 19.0, "temp_range": 4.0, "rh_mean": 58, "rh_range": 10},
}

F_SEASON_BY_KEY = {
    "winter": 0.92,
    "pre_monsoon": 1.12,
    "monsoon": 0.96,
    "post_monsoon": 1.01,
}

# Real dual-peak Gaussian sewage demand parameters (7 AM & 7 PM peaks)
B_DEM = 0.3
A1_DEM, MU1_DEM, SIGMA1_DEM = 1.3, 7.0, 1.5
A2_DEM, MU2_DEM, SIGMA2_DEM = 1.2, 19.0, 2.5
NORM_CONST = 0.7673


# continuous real-time drain physics simulator
class LiveDrainEnv:
    def __init__(self):
        self.step_idx = 0
        self.sim_hours = 0.0

        # physical specs
        self.catchment_m2 = 12000.0
        self.runoff_coef = 0.75
        self.base_sewage_lps = 6.0
        self.pipe_cap_lps = 350.0
        self.max_lvl_cm = 100.0

        # drain smoothing inertia (time constant)
        self.alpha = 0.40
        self.smoothed_flow = 6.0

        # current state
        self.current_state = {}
        self.step(blk, pop, rn, seasons[s_idx], hr_add)

    # not used anymore but keeping it
    # def dump_readings(self, fname="test_run.csv"):
    #     with open(fname, "w") as f:
    #         for idx in range(100):
    #             f.write(f"{idx}\n")
    #     print("dumped")

    def step(self, blk_pct, pop_mul, forced_rain, forced_season, hr_offset):
        # advance 1 hour per step
        hr_raw = int(self.sim_hours) % 24
        day_raw = int(self.sim_hours // 24) % 365

        # determine month
        mon_idx = min(11, day_raw // 30)
        cur_month = MONTH_NAMES[mon_idx]
        cur_season = MONTH_TO_SEASON[cur_month] if forced_season == "auto" else forced_season

        effective_hr = (hr_raw + hr_offset) % 24

        # 1. Real Climate equations
        clim = MONTHLY_CLIMATE[cur_month]
        ph = 2.0 * math.pi * (effective_hr - 15.0) / 24.0
        temp_c = clim["temp_mean"] + clim["temp_range"] * math.cos(ph) + random.gauss(0, 0.2)
        rh_pct = clim["rh_mean"] - clim["rh_range"] * math.cos(ph)

        # 2. Weather & rain determination
        if forced_rain > 0:
            rain_mm = float(forced_rain)
            if rain_mm < 2.0:
                wx = "drizzle"
            elif rain_mm < 8.0:
                wx = "light_rain"
            elif rain_mm < 20.0:
                wx = "moderate_rain"
            else:
                wx = "heavy_rain"
            rh_pct += 12.0
        else:
            # stochastic natural rain chance based on season
            p_monsoon = 0.12 if cur_season == "monsoon" else 0.015
            if random.random() < p_monsoon:
                rain_mm = random.uniform(1.0, 14.0)
                wx = "moderate_rain" if rain_mm > 5 else "light_rain"
                rh_pct += 10.0
            else:
                rain_mm = 0.0
                wx = "clear" if random.random() < 0.65 else "cloudy"

        rh_pct = max(20.0, min(98.0, rh_pct))

        # climate demand factor E
        ft = max(0.80, min(1.25, 1.0 + (temp_c - 26.0) / 15.0))
        fh = max(0.90, min(1.10, 1.0 - (rh_pct - 55.0) / 50.0 * 0.10))
        fs = F_SEASON_BY_KEY.get(cur_season, 1.0)
        fw = 1.04 if wx == "clear" else (1.0 if wx == "cloudy" else 0.88)
        E = max(0.70, min(1.45, ft * fh * fs * fw))

        # 3. Real Dual-Peak Gaussian Sewage Demand
        m_peak = A1_DEM * math.exp(-((effective_hr - MU1_DEM)**2) / (2.0 * SIGMA1_DEM**2))
        e_peak = A2_DEM * math.exp(-((effective_hr - MU2_DEM)**2) / (2.0 * SIGMA2_DEM**2))
        q_raw = (B_DEM + m_peak + e_peak) / NORM_CONST
        demand_index = E * q_raw

        # base sewage flow
        sewage_lps = self.base_sewage_lps * pop_mul * demand_index

        # 4. Real Stormwater Runoff (rain_mm * area * coef / 3600s)
        runoff_lps = (rain_mm) * self.catchment_m2 * self.runoff_coef / 3600.0

        # total inflow with stochastic noise
        flow_noise = random.gauss(0, 0.02 * self.base_sewage_lps)
        inflow_lps = max(0.0, runoff_lps + sewage_lps + flow_noise)

        # 5. Continuous Exponential Moving Average (Drain Inertia)
        self.smoothed_flow = self.alpha * inflow_lps + (1.0 - self.alpha) * self.smoothed_flow

        # 6. Physical Pipe Capacity Choking by Blockage
        eff_capacity = max(1.0, self.pipe_cap_lps * (1.0 - (blk_pct / 100.0)))

        # 7. Real Exponential Level Saturation Equation (from SentinelENV.py)
        # lvl = max_lvl * (1.0 - exp(-smoothed_flow / pipe_capacity))
        level_cm = self.max_lvl_cm * (1.0 - math.exp(-self.smoothed_flow / eff_capacity))
        level_cm += random.gauss(0, 0.15)
        level_cm = max(0.0, min(self.max_lvl_cm, level_cm))

        self.sim_hours += 1.0
        self.step_idx += 1

        self.current_state = {
            "hour": effective_hr,
            "month": cur_month,
            "season": cur_season,
            "weather_state": wx,
            "temp_c": temp_c,
            "rh_pct": rh_pct,
            "rain_mm": rain_mm,
            "demand_index": demand_index,
            "inflow_lps": inflow_lps,
            "smoothed_flow_lps": self.smoothed_flow,
            "eff_cap": eff_capacity,
            "level_cm": level_cm,
        }

    def reset(self):
        self.sim_hours = 0.0
        self.step_idx = 0
        self.smoothed_flow = 6.0
        self.step(blk, pop, rn, seasons[s_idx], hr_add)


pygame.init()

WIDTH = 1200
HEIGHT = 700

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Sentinel Live Physics SIM")

c1 = (135, 206, 235)
c2 = (10, 15, 41)

b_1 = (169, 169, 169)
b_2 = (105, 105, 105)

road = (50, 50, 50)
brown = (101, 67, 33)

pipeLine = (192, 192, 192)
pipe = (30, 30, 30)
water = (0, 119, 190)

dash = (128, 128, 128)

setBg = (55, 55, 60)
btnUp = (70, 165, 70)
btnDn = (175, 70, 70)
btnRun = (45, 130, 210)
btnP = (200, 140, 40)

px = 0
py = 530
pw = 800
ph = 100

ft = pygame.font.SysFont('couriernew', 32, bold=True)
ftext = pygame.font.SysFont('Arial', 24)
fsmall = pygame.font.SysFont('Arial', 18)
ftiny = pygame.font.SysFont('Arial', 14)


def dayCyle(screen, t):
    r = c1[0] + (c2[0] - c1[0]) * t
    g = c1[1] + (c2[1] - c1[1]) * t
    b = c1[2] + (c2[2] - c1[2]) * t
    screen.fill((r, g, b))


def drawBG(screen):
    pygame.draw.rect(screen, b_1, (50, 150, 100, 250))
    pygame.draw.rect(screen, b_2, (180, 100, 120, 300))
    pygame.draw.rect(screen, b_1, (320, 200, 90, 200))
    pygame.draw.rect(screen, b_2, (450, 80, 150, 320))
    pygame.draw.rect(screen, b_1, (650, 180, 100, 220))

    pygame.draw.rect(screen, road, (0, 400, WIDTH, 100))
    pygame.draw.rect(screen, brown, (0, 500, WIDTH, 200))
    pygame.draw.rect(screen, pipe, (0, py, pw, ph))


ENV = LiveDrainEnv()


def drawDash(screen):
    pygame.draw.rect(screen, dash, (825, 0, 400, 310))

    ts = ft.render("Live Drain Physics", True, (0, 0, 0))
    screen.blit(ts, (840, 20))

    st = ENV.current_state

    stats = [
        f"Time : {st['hour']}:00 ({st['month'][:3]})",
        f"Water Lvl: {st['level_cm']:.2f} cm",
        f"Inflow: {st['inflow_lps']:.1f} L/s",
        f"Pipe Cap: {st['eff_cap']:.1f} L/s",
        f"Temp: {st['temp_c']:.1f} C",
        f"Season: {st['season']}",
        f"Weather: {st['weather_state']}",
        f"Rain: {st['rain_mm']:.1f} mm",
        f"Blockage: {blk}%",
    ]

    y = 55
    for stat_text in stats:
        text_surface = ftext.render(stat_text, True, (255, 255, 255))
        screen.blit(text_surface, (840, y))
        y += 27

    return st['level_cm'], st['hour']


bRects = []
pRect = None
rstRect = None


def drawSettings(screen):
    global bRects, pRect, rstRect
    bRects = []

    panY = 320
    pygame.draw.rect(screen, setBg, (825, panY, 400, HEIGHT - panY))

    st = ftext.render("-- Live Controls --", True, (210, 210, 210))
    screen.blit(st, (875, panY + 8))

    ctrls = [
        ("Blockage", f"{blk}%", "blk"),
        ("Population", f"{pop:.1f}x", "pop"),
        ("Rain", f"+{rn}mm", "rn"),
        ("Season", f"{seasons[s_idx]}", "seas"),
        ("Time(hr)", f"{'+' if hr_add>=0 else ''}{hr_add}h", "hr"),
        ("Speed", f"{sp} fps", "sp"),
    ]

    sy = panY + 38
    for lbl, val_str, tag in ctrls:
        ls = fsmall.render(f"{lbl}:", True, (200, 200, 200))
        screen.blit(ls, (835, sy + 2))

        vs = fsmall.render(val_str, True, (255, 255, 255))
        screen.blit(vs, (975, sy + 2))

        uR = pygame.Rect(1070, sy, 26, 22)
        pygame.draw.rect(screen, btnUp, uR)
        ut = ftiny.render("+", True, (255, 255, 255))
        screen.blit(ut, (uR.x + 8, uR.y + 3))

        dR = pygame.Rect(1105, sy, 26, 22)
        pygame.draw.rect(screen, btnDn, dR)
        dt = ftiny.render("-", True, (255, 255, 255))
        screen.blit(dt, (dR.x + 9, dR.y + 3))

        bRects.append((tag, "up", uR))
        bRects.append((tag, "dn", dR))

        sy += 28

    ry = sy + 15

    pRect = pygame.Rect(840, ry, 95, 32)
    pColor = (180, 50, 50) if psd else btnP
    pygame.draw.rect(screen, pColor, pRect, border_radius=4)
    pTxt = "Resume" if psd else "Pause"
    pt_surf = fsmall.render(pTxt, True, (255, 255, 255))
    screen.blit(pt_surf, (pRect.x + 18, pRect.y + 6))

    rstRect = pygame.Rect(950, ry, 80, 32)
    pygame.draw.rect(screen, btnRun, rstRect, border_radius=4)
    rt = fsmall.render("Reset", True, (255, 255, 255))
    screen.blit(rt, (rstRect.x + 18, rstRect.y + 6))

    ptxt = f"Tick {ENV.step_idx}"
    ps = ftiny.render(ptxt, True, (160, 160, 160))
    screen.blit(ps, (1045, ry + 10))


def doClick(mx, my):
    global blk, pop, rn, s_idx, hr_add, sp, psd

    for tag, dr, rect in bRects:
        if rect.collidepoint(mx, my):
            if tag == "blk":
                blk = min(100, blk + blk_step) if dr == "up" else max(0, blk - blk_step)
            elif tag == "pop":
                pop = round(min(5.0, pop + pop_step), 1) if dr == "up" else round(max(0.2, pop - pop_step), 1)
            elif tag == "rn":
                rn = min(100, rn + rn_step) if dr == "up" else max(0, rn - rn_step)
            elif tag == "seas":
                s_idx = (s_idx + 1) % len(seasons) if dr == "up" else (s_idx - 1) % len(seasons)
            elif tag == "hr":
                hr_add = (hr_add + 1) % 24 if dr == "up" else (hr_add - 1) % 24
            elif tag == "sp":
                sp = min(60, sp + sp_step) if dr == "up" else max(1, sp - sp_step)
            return

    if pRect and pRect.collidepoint(mx, my):
        psd = not psd
        return

    if rstRect and rstRect.collidepoint(mx, my):
        blk = 0
        pop = 1.0
        rn = 0
        s_idx = 0
        hr_add = 0
        sp = 5
        psd = False
        ENV.reset()
        print("Reset live physics")
        return


def drawW(screen, wl):
    wh = (ph * wl) / 100
    y = py + ph - wh
    pygame.draw.rect(screen, water, (px, y, pw, wh))
    pygame.draw.rect(screen, pipeLine, (px, py, pw, ph), 5)


# def draw(t):
#     wl = GetWL()
#     wl = max(0, min(100, wl))
#     dayCyle(screen,t)
#     drawBG(screen)
#     drawDash(screen,t)
#
#     water_pixel_height = (ph * wl) / 100
#     water_y = py + ph - water_pixel_height
#     pygame.draw.rect(screen, water, (px, water_y, pw, water_pixel_height))
#     pygame.draw.rect(screen, pipeLine, (px, py, pw, ph), 5)


clock = pygame.time.Clock()
r = True
t = 0


async def main():
    global r, t, psd
    while r:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                r = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    doClick(event.pos[0], event.pos[1])
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    psd = not psd

        dayCyle(screen, t)
        drawBG(screen)

        wl, cur_hr = drawDash(screen)

        t = (cur_hr - 1) / 23.0
        t = max(0.0, min(1.0, t))

        drawW(screen, wl)
        drawSettings(screen)

        if not psd:
            ENV.step(blk, pop, rn, seasons[s_idx], hr_add)

        pygame.display.flip()
        clock.tick(sp)
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
